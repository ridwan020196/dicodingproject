/*
        jangan ubah kode di bawah ini ya!
*/

import "regenerator-runtime";
import "bootstrap/dist/css/bootstrap.min.css";
import "./styles/main.css";
import main from "./scripts/main.js";

main();
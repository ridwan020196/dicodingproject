function main() 
 $('search-button').on('click', function () {
     $.ajax ({
        url: 'http://omdbapi.com',
        type: 'get',
        dataType: 'json',
        data: {
            'apikey' : '1b1644bd',
            's' : $('#search-input').val()
        },
        success :  function(result) {
            console.log(result); 
        }
     });
 });
   

export default main;
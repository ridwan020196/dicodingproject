/*
        jangan ubah kode di bawah ini ya!
*/

import "regenerator-runtime";
import "bootstrap/dist/css/bootstrap.min.css";
import "./styles/main.css";
import "./scripts/nav-bar.js"
import "./scripts/movie-list.js"
import main from "./scripts/main";


main();
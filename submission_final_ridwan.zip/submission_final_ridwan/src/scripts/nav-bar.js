class navbar extends HTMLElement {

    constructor() {
        super();
        this.shadowDOM = this.attachShadow({mode: "open"});
    }

    connectedCallback(){
        this.render();
    }

    render() {
        this.shadowDOM.innerHTML = `
        <style>
        header {
            display: inline;
         }
         
         .logo {
             color :white;
             letter-spacing: 2px;
         }
         
         
         nav {
             display: flex;
             background-color:#EC0101;
             justify-content: space-between;
             height: 70px;
           position: sticky;
           right : 100px;
           top: 0;
         }
         h3{
             margin-left :40px;
         }
        </style>
<header>
		<nav>
			<div class="logo">
				<h3 class="logo">Film Readone</h3>
			</div>
	    </nav>
</header>`;
    }
}

customElements.define("nav-bar", navbar);
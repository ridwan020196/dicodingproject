class SearchBar extends HTMLElement {
 
    constructor() {
        super();
        this.shadowDOM = this.attachShadow({mode: "open"});
    }
  
    connectedCallback(){
        this.render();
    }
   
    set clickEvent(event) {
        this._clickEvent = event;
        this.render();
    }
  
    get value() {
        return this.shadowDOM.querySelector("#search-button").value;
    }
  
        render() {
        this.shadowDOM.innerHTML = `
        <div class="input-group mb-3">
                    <input type="text" class="form-control" id="search-input" placeholder="Cari Film Favourite">
                    <div class="input-group-append">
                    <button class="btn btn-dark bg-primary" type="button" id="search-button">Cari</button>
                </div>
          </div>
        `;
  
        this.shadowDOM.querySelector("#search-input").addEventListener("click", this._clickEvent);
    }
 }
  
 customElements.define("search-bar", SearchBar);